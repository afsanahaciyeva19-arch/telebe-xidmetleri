@echo off
setlocal
cd /d "%~dp0"
where npm.cmd >nul 2>&1
if errorlevel 1 (
  echo Node.js LTS is required. Install it from https://nodejs.org/en/download and run this file again.
  pause
  exit /b 1
)
call npm.cmd install
if errorlevel 1 goto failed
call npx.cmd netlify-cli login
if errorlevel 1 goto failed
echo Select the existing project: prismatic-halva-c967f2
call npx.cmd netlify-cli link
if errorlevel 1 goto failed
echo Confirm the linked project above before publishing.
choice /C YN /M "Publish to the linked Netlify project"
if errorlevel 2 exit /b 0
call npx.cmd netlify-cli deploy --prod
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Publishing stopped. See the error above.
pause
exit /b 1
