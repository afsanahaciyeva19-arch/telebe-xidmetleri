const CACHE_NAME="telebe-xidmetleri-v17-netlify";
const APP_SHELL=["./","./index.html","./manifest.webmanifest","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",e=>{
  e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(APP_SHELL)));
  self.skipWaiting();
});
self.addEventListener("activate",e=>{
  e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch",e=>{
  const r=e.request;
  if(r.method!=="GET") return;
  const u=new URL(r.url);
  if(u.origin!==self.location.origin) return;
  if(u.pathname.startsWith("/api/") || u.pathname.startsWith("/.netlify/") || u.pathname === "/admin.html" || u.pathname === "/admin") return;
  if(r.mode==="navigate"){
    e.respondWith(fetch(r).catch(()=>caches.match(u.pathname === "/" || u.pathname === "/index.html" ? "./index.html" : r).then(res=>res||Response.error())));
    return;
  }
  e.respondWith(caches.match(r).then(c=>c||fetch(r).then(res=>{
    const cp=res.clone();
    caches.open(CACHE_NAME).then(cache=>cache.put(r,cp));
    return res;
  })));
});
