import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { getStore } from '@netlify/blobs';

const kinds = new Set(['Sual', 'Təklif', 'Ərizə', 'Şikayət', 'Arayış']);
const statuses = ['Gözləmədə', 'İcradadır', 'Cavablandırılıb'];
const ticketPattern = /^(?:BBU-[1-9][0-9]{0,12}|[0-9A-Z]{8}|MR-[A-F0-9]{12}-[A-F0-9]{16})$/;
const accessCodePattern = /^(?:[A-Z0-9]{1,12}-[A-Z0-9]{1,12}-[2-9A-HJ-NP-Z]{6,8}|[2-9A-HJ-NP-Z]{8}|[A-F0-9]{16})$/;
const ticketEpoch = Date.UTC(2020, 0, 1);
const accessAlphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

function ticketTime(ticket) {
  return ticket.startsWith('MR-') ? parseInt(ticket.slice(3, 15), 16) :
    ticketEpoch + parseInt(ticket, 36);
}

function newestFirst(left, right) {
  const leftSequence = left.startsWith('BBU-');
  const rightSequence = right.startsWith('BBU-');
  if (leftSequence !== rightSequence) return rightSequence ? 1 : -1;
  if (leftSequence) return Number(right.slice(4)) - Number(left.slice(4));
  return ticketTime(right) - ticketTime(left) || right.localeCompare(left);
}
const missing = 'Müraciət tapılmadı və ya giriş kodu yanlışdır';

function json(data, status = 200) {
  return Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
}

function error(message, status) {
  return json({ error: message }, status);
}

function digest(value) {
  return createHash('sha256').update(value).digest('hex');
}

function matches(actual, expected) {
  return timingSafeEqual(Buffer.from(actual), Buffer.from(expected));
}

const bakuClock = new Intl.DateTimeFormat('en-GB', {
  timeZone: 'Asia/Baku', year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
});

function bakuTime(value) {
  if (typeof value !== 'string' || !value.endsWith(' UTC')) return value;
  const date = new Date(value.slice(0, -4).replace(' ', 'T') + ':00Z');
  if (Number.isNaN(date.getTime())) return value;
  const parts = Object.fromEntries(bakuClock.formatToParts(date).map(({ type, value }) => [type, value]));
  return parts.day + '.' + parts.month + '.' + parts.year + ', ' + parts.hour + ':' + parts.minute + ' (Bakı vaxtı)';
}

function displayHistory(history) {
  return history.map(item => ({ ...item, changed_at: bakuTime(item.changed_at) }));
}

function timestamp() {
  return new Date().toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
}

function field(data, key) {
  return typeof data?.[key] === 'string' ? data[key].trim() : '';
}

async function readBody(request) {
  if (!request.headers.get('content-type')?.startsWith('application/json')) return null;
  try {
    const bytes = await request.arrayBuffer();
    if (bytes.byteLength > 40000) return null;
    return JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    return null;
  }
}

const certificateFields = [
  [
    "first",
    "Ad",
    "text",
    1
  ],
  [
    "last",
    "Soyad",
    "text",
    1
  ],
  [
    "father",
    "Ata adı",
    "text",
    1
  ],
  [
    "birth",
    "Doğum tarixi",
    "date",
    1
  ],
  [
    "faculty",
    "Fakültə",
    "text",
    1
  ],
  [
    "major",
    "İxtisas",
    "text",
    1
  ],
  [
    "course",
    "Kurs",
    "text",
    1
  ],
  [
    "group",
    "Qrup",
    "text",
    1
  ],
  [
    "phone",
    "Telefon nömrəsi",
    "tel",
    1
  ],
  [
    "type",
    "Arayışın növü",
    "text",
    1
  ],
  [
    "destination",
    "Arayışın təqdim ediləcəyi yer",
    "text",
    0
  ],
  [
    "term",
    "Normativ təhsil müddətini keçmisiniz?",
    "choice",
    1
  ],
  [
    "previous",
    "Bundan əvvəl arayış almısınız?",
    "choice",
    0
  ],
  [
    "previousType",
    "Hansı arayışı almısınız?",
    "text",
    0
  ],
  [
    "note",
    "Əlavə qeyd",
    "textarea",
    0
  ]
];
function certificateDetails(data) {
  const values = Object.fromEntries(certificateFields.map(([key]) => [key, field(data, key)]));
  if (values.previous !== 'Bəli') values.previousType = '';
  if (certificateFields.some(([key, , , required]) =>
      (required && !values[key]) || values[key].length > (key === 'note' ? 1000 : 150))) return null;
  const birth = new Date(values.birth);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(values.birth) || Number.isNaN(birth.getTime()) ||
      birth.toISOString().slice(0, 10) !== values.birth || birth.getTime() > Date.now()) return null;
  if (!['Bəli', 'Xeyir'].includes(values.term) ||
      !['', 'Bəli', 'Xeyir'].includes(values.previous) ||
      (values.previous === 'Bəli' && !values.previousType)) return null;
  return {
    fullname: [values.first, values.last, values.father].join(' '),
    message: certificateFields.filter(([key]) => values[key])
      .map(([key, label]) => label + ': ' + values[key]).join('\n')
  };
}

function codePart(value, fallback) {
  return value.toUpperCase().replaceAll('Ə', 'E').replaceAll('İ', 'I')
    .normalize('NFD').replace(/[^A-Z0-9]/g, '').slice(0, 12) || fallback;
}

function newAccessCode(firstName, group) {
  const suffix = Array.from(randomBytes(6), byte => accessAlphabet[byte & 31]).join('');
  return [codePart(firstName, 'AD'), codePart(group, 'QRUP'), suffix].join('-');
}

async function reserveTicket(store) {
  const key = 'bbu-sequence';
  for (let attempt = 0; attempt < 32; attempt++) {
    const current = await store.getWithMetadata(key, { type: 'json' });
    const number = (current?.data?.last ?? 0) + 1;
    const condition = current ? { onlyIfMatch: current.etag } : { onlyIfNew: true };
    const result = await store.setJSON(key, { last: number }, condition);
    if (result.modified) return 'BBU-' + number;
    await new Promise(resolve => setTimeout(resolve, randomBytes(1)[0]));
  }
  return null;
}

async function createRequest(store, request) {
  const data = await readBody(request);
  const student_group = field(data, 'group');
  const kind = field(data, 'kind');
  const details = kind === 'Arayış' ? certificateDetails(data) : {
    fullname: field(data, 'fullname'), message: field(data, 'message')
  };
  if (!details) return error('Arayış formasındakı məlumatları yoxlayın', 400);
  const { fullname, message } = details;
  if (!fullname || fullname.length > (kind === 'Arayış' ? 452 : 150) || !student_group || student_group.length > 60 ||
      !message || message.length > 5000 || !kinds.has(kind)) {
    return error('Məlumatları düzgün doldurun', 400);
  }

  const firstName = kind === 'Arayış' ? field(data, 'first') : fullname.split(/\s+/, 1)[0];
  const access_code = newAccessCode(firstName, student_group);
  const created_at = timestamp();
  const status = statuses[0];
  const row = {
    fullname, student_group, kind, message, status,
    accessHash: digest(access_code), reply: '', created_at, updated_at: created_at,
    history: [{ changed_at: created_at, status, reply: '' }]
  };
  const ticket = await reserveTicket(store);
  if (!ticket) return error('Bir az sonra yenidən cəhd edin', 503);
  const result = await store.setJSON(ticket, { ...row, ticket }, { onlyIfNew: true });
  if (!result.modified) return error('Bir az sonra yenidən cəhd edin', 503);
  return json({ ticket, access_code, status }, 201);
}

async function checkStatus(store, request) {
  const data = await readBody(request);
  const ticket = field(data, 'ticket').toUpperCase();
  const code = field(data, 'access_code').toUpperCase();
  if (!ticketPattern.test(ticket) || !accessCodePattern.test(code)) {
    return error(missing, 404);
  }
  const row = await store.get(ticket, { type: 'json' });
  if (!row || !matches(digest(code), row.accessHash)) return error(missing, 404);
  const { status, reply, created_at, updated_at, history } = row;
  return json({ ticket, status, reply, created_at: bakuTime(created_at),
    updated_at: bakuTime(updated_at), history: displayHistory(history) });
}

async function listRequests(store, before) {
  const { blobs } = await store.list();
  const keys = blobs.map(({ key }) => key)
    .filter(key => ticketPattern.test(key) && (!ticketPattern.test(before ?? '') || newestFirst(key, before) > 0))
    .sort(newestFirst);
  const entries = await Promise.all(keys.slice(0, 25).map(key =>
    store.getWithMetadata(key, { type: 'json' })
  ));
  const requests = entries.filter(Boolean).map(({ data, etag }) => {
    const { accessHash, ...row } = data;
    return { ...row, created_at: bakuTime(row.created_at), updated_at: bakuTime(row.updated_at),
      history: displayHistory(row.history), revision: etag };
  });
  return json({ requests, next: keys.length > 25 ? keys[24] : null });
}

async function updateRequest(store, request, ticket) {
  if (!ticketPattern.test(ticket)) return error('Müraciət tapılmadı', 404);
  const data = await readBody(request);
  const { status, reply, revision } = data ?? {};
  const resetCode = data?.resetCode === true;
  if (typeof revision !== 'string' || (!resetCode && (typeof reply !== 'string' || reply.length > 5000))) {
    return error('Məlumat yanlışdır', 400);
  }
  const entry = await store.getWithMetadata(ticket, { type: 'json' });
  if (!entry) return error('Müraciət tapılmadı', 404);
  const row = entry.data;
  const conflict = 'Müraciət yenilənib. Siyahını yeniləyin və yenidən cəhd edin.';
  if (revision !== entry.etag) return error(conflict, 409);
  if (resetCode) {
    const firstName = row.fullname.split(/\s+/, 1)[0];
    let access_code;
    let accessHash;
    do {
      access_code = newAccessCode(firstName, row.student_group);
      accessHash = digest(access_code);
    } while (matches(accessHash, row.accessHash));
    const result = await store.setJSON(ticket, { ...row, accessHash }, { onlyIfMatch: revision });
    if (!result.modified) return error(conflict, 409);
    return json({ revision: result.etag, access_code });
  }
  if (!statuses.includes(status) && !(row.kind === 'Arayış' && status === 'Hazırdır')) {
    return error('Vəziyyət yanlışdır', 400);
  }
  if (row.status === status && row.reply === reply) return json({ revision });

  const updated_at = timestamp();
  const updated = {
    ...row, status, reply, updated_at,
    history: [...row.history, { changed_at: updated_at, status, reply }]
  };
  const result = await store.setJSON(ticket, updated, { onlyIfMatch: revision });
  if (!result.modified) return error(conflict, 409);
  return json({ revision: result.etag, history: displayHistory(updated.history) });
}

export function makeHandler(openStore, getAdminToken) {
  return async request => {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method;
    try {
      const secret = getAdminToken();
      if (!secret || secret.length < 16) return error('Xidmət hələ qurulmayıb', 503);
      if (pathname === '/api/requests' && method === 'POST') {
        return await createRequest(openStore(), request);
      }
      if (pathname === '/api/status' && method === 'POST') {
        return await checkStatus(openStore(), request);
      }
      if (pathname === '/api/admin/requests' || pathname.startsWith('/api/admin/requests/')) {
        const encodedToken = request.headers.get('X-Admin-Token-Encoded');
        let token = request.headers.get('X-Admin-Token') || '';
        if (encodedToken !== null) {
          try {
            token = decodeURIComponent(encodedToken);
          } catch {
            return error('Administrator kodu yanlışdır', 401);
          }
        }
        if (!matches(digest(token), digest(secret))) {
          return error('Administrator kodu yanlışdır', 401);
        }
        if (pathname === '/api/admin/requests' && method === 'GET') {
          return await listRequests(openStore(), url.searchParams.get('before'));
        }
        if (method === 'PATCH') {
          return await updateRequest(openStore(), request, pathname.split('/').at(-1));
        }
      }
      return error('Tapılmadı', 404);
    } catch (err) {
      console.error('Request service error', err?.name);
      return error('Xidmət müvəqqəti əlçatan deyil. Bir az sonra yenidən cəhd edin.', 503);
    }
  };
}

export default makeHandler(
  () => getStore({ name: 'student-requests', consistency: 'strong' }),
  () => process.env.ADMIN_TOKEN
);

export const config = {
  path: ['/api/requests', '/api/status', '/api/admin/requests', '/api/admin/requests/:ticket'],
  rateLimit: { action: 'rate_limit', aggregateBy: ['ip'], windowSize: 60, windowLimit: 100 }
};
